# SearchEngine
Gonna make some (i hope) simple search engine. For assignment tho.

ScrapingHub, if you look for periodic deploy

## To do:

* Web Crawling (Done, using Scrapy, python)
* Data Cleaning
* Indexing
* Query
* Or any other.

## Platform that i want to use

* Python, using Scrapy Library for crawling and data cleaning
* Php, for building an interface of search engine

